package com.example.demo2.Dzieci;

import org.springframework.stereotype.Component;

@Component ("Jan")
public class Jas extends Dziecko{
}
