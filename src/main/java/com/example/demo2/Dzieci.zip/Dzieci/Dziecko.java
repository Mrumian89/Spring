package com.example.demo2.Dzieci;

public class Dziecko {

  public void daj(Present present) {
  System.out.println("Daj prezent: " + present.getNazwa());
    }
}
