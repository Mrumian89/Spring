package com.example.demo2.Dzieci;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Present {

    private String nazwa;

}
