package com.example.demo2.Dzieci;

import org.springframework.stereotype.Component;

@Component ("Malgorzata")

public class Malgosia extends Dziecko {
}
