package com.example.demo2.Dzieci;

import org.springframework.stereotype.Component;

@Component("Lobuz")
public class Zbys extends Dziecko {
}
