package com.example.demo2.model;

public interface Czesc {
}
