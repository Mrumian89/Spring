package com.example.demo2.model;

import org.springframework.stereotype.Component;

@Component
public class Kluczyki {
}
