package com.example.demo2;

import org.springframework.stereotype.Component;

@Component
public class AplikacjaDoWyszukania {
}

